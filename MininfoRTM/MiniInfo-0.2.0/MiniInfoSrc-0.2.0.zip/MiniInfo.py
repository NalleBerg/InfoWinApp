# Copyleft Nalle Berg 2025
# License GPL V2
AppVersion = '0.2.0'


import tkinter as tk					 
from tkinter import ttk
import psutil
from psutil import disk_partitions
from psutil._common import bytes2human
import urllib.request
import socket
import wmi
import platform
import sys

# Language file:
# To be implemented in next version!
# exec(open('NO_nb_lang').read())
# print (networktitle)



def main():
    # Local IP & Default Gateway I do the querys here to use to detemine if you are on net and internet
	wmi_obj = wmi.WMI()
	wmi_sql = "select IPAddress,DefaultIPGateway from Win32_NetworkAdapterConfiguration where IPEnabled=TRUE"
	wmi_out = wmi_obj.query( wmi_sql )
	
	# For some diskinfo as bus, type and model used in a for-loop
	wmi_obj_1 = wmi.WMI(namespace='root/Microsoft/Windows/Storage')
 
	# Checking if you are at all on the network.
 	# Expecting you will always have a IPv4 address on your local netwok i ask for it.
	# It is bolean, just to make it easier to query for it later.
	for dev in wmi_out:
		LocalIPv4 = dev.IPAddress[0]
	try:
		LocalIPv4
	except NameError:
		OnNetWork = False
	else:
		OnNetWork = True
  
	
	# We also need to know if we're on the internet.
	REMOTE_SERVER = "one.one.one.one"
	def is_connected(hostname):
		try:
    		# See if we can resolve the host name - tells us if there is
    		# A DNS listening
			host = socket.gethostbyname(hostname)
   			# Connect to the host - tells us if the host is actually reachable
			s = socket.create_connection((host, 80), 2)
			s.close()
			return True
		except Exception:
			pass # We ignore errors, only looking for True

    # Google to the rescue! It's always there.
	OnInternet = is_connected('www.google.com')
	
    
	# Making the app know it's path.
	# Importin os here, since it for some rason had to be within main()
	import os
	def resource_path(relative_path):
		try:
			base_path = sys._MEIPASS
		except Exception:
			base_path = os.path.abspath(".")

		return os.path.join(base_path, relative_path)
	# Defining the window
	Window = tk.Tk() 
	# Adding title
	Window.title("MiniInfo")
	# For your own icon 
	#ICO = tk.PhotoImage(file=(resource_path("xxx.PNG"))) 
	#Window.iconphoto(True, ICO)

	hdd = psutil.disk_usage('C:/')

	# Getting the memory information
	mem = psutil.virtual_memory()
	swap = psutil.swap_memory()

	# Getting CPU information
	cpufreq = psutil.cpu_freq()
	CPUProc = platform.processor()

	tabControl = ttk.Notebook(Window)

	tab1 = ttk.Frame(tabControl) 
	tab2 = ttk.Frame(tabControl) 
	tab3 = ttk.Frame(tabControl) 
	tab4 = ttk.Frame(tabControl)
	tab5 = ttk.Frame(tabControl)
	tab6 = ttk.Frame(tabControl)
	

	tabControl.add(tab1, text ='Nettverk') # Eng: Network
	tabControl.add(tab2, text ='CPU') # Eng: CPU
	tabControl.add(tab3, text ='Minne') # Eng: Memory
	tabControl.add(tab4, text ='Disk(er)') # Eng: Disk(s)
	tabControl.add(tab5, text ='Operativsystem') # Eng: Operating system 
	tabControl.add(tab6, text ='Om Programmet') # About the program

	tabControl.pack(expand = 1, fill ="both") 
	

	# Memory fetch and format
	memsize = bytes2human(mem.total).replace(',', ' ').replace('.',',')
	memused = bytes2human(mem.used).replace(',', ' ').replace('.',',')
	memfree = bytes2human(mem.free).replace(',', ' ').replace('.',',')

	# Swap fetch and format
	swaptotal = bytes2human(swap.total).replace(',', ' ').replace('.',',')
	swapused = bytes2human(swap.used).replace(',', ' ').replace('.',',')
	swapfree = bytes2human(swap.free).replace(',', ' ').replace('.',',')

	
	if OnNetWork:
		for dev in wmi_out:
			DefGWv4 = dev.DefaultIPGateway[0] 
			DefGWv6 = dev.DefaultIPGateway[1]
			LocalIPv4 = dev.IPAddress[0]
			LocalIPv6 = dev.IPAddress[1]
  
		# Networkadapter (active) an it's Mac address
		for interface in wmi_obj.Win32_NetworkAdapterConfiguration (IPEnabled=1):
			ActiveNetCard = interface.Description 
			MacAddr = interface.MACAddress


		# Network info, fetching
		# Hostname
		hostname = socket.gethostname()
	if OnInternet:
 		# External IP
		external_ip_v4 = urllib.request.urlopen('https://ipv4.ident.me').read().decode('utf8')
		external_ip_v6 = urllib.request.urlopen('https://ipv6.ident.me').read().decode('utf8')
	
	# OS
	# OS name
	for os in wmi_obj.Win32_OperatingSystem():
		OSName = os.caption
  
	OSVersion = platform.version()
	OSMachine = platform.machine()

	# Displaying
 
	# Network 
	ttk.Label(tab1, 
		text ="Nettverk\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
									row = 0, 
									padx = 10, 
									pady = 3,
                                    columnspan=2) # Eng: Network
	
	ttk.Label(tab1, 
		text ="Nettverkskort\n(aktivt kort)", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 1, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Network card (active card)
	# If there is no net
	if not OnNetWork:
		ActiveNetCard = "Ingen aktive nettverkskort" # Eng: No active network cards
  
	ttk.Label(tab1, 
		text = ActiveNetCard+"\n ", anchor="w").grid(column = 1, 
									row = 1, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 
  
	
	ttk.Label(tab1, 
		text ="Maskinens nettverksnavn\n ", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 2, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Machine's network name
	# If no network
	if not OnNetWork:
		hostname = "Ingen aktive nettverkskort" # Eng: No active network cards
	
	ttk.Label(tab1, 
		text = hostname+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 2, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	
	ttk.Label(tab1, 
		text ="Lokal IP-adresse V4\n ", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 3, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Local IP address V4
	# If no network
	if not OnNetWork:
		LocalIPv4 = "Ingen aktive nettverkskort" # Eng: No active network cards
  
	ttk.Label(tab1, 
		text = LocalIPv4+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 3, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	# Local IP address V6
	ttk.Label(tab1, 
		text ="Lokal IP-adresse V6\n ", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 4, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 
	# If no network
	if not OnNetWork:
		LocalIPv6 = "Ingen aktive nettverkskort" # Eng: No active network cards

	ttk.Label(tab1, 
		text = LocalIPv6+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 4, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	
	ttk.Label(tab1, 
		text ="Ekstern IP-adresse V4\n ", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 5, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng External IP Address V4
	# If no Internet
	if not OnInternet:
		external_ip_v4 = "Ikke på internett" # Eng:Not on Internet 
  
	ttk.Label(tab1, 
		text = external_ip_v4+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 5, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 
	ttk.Label(tab1, 
		text ="Ekstern IP-adresse V6\n ", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 6, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: External IP-address V6
	# If no Internet
	if not OnInternet:
		external_ip_v6 = "Ikke på internett" # Eng:Not on Internet 
  
	ttk.Label(tab1, 
		text = external_ip_v6+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 6, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 
	ttk.Label(tab1, 
		text ="Standard Gatewy V4\n(Dette er routeren din)", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 7, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Default Gateway V4\n(This is your router)
  
	if not OnNetWork:
		DefGWv4 = "Ingen aktive nettverkskort" # Eng: No active network cards

	ttk.Label(tab1, 
		text =DefGWv4+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 7, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 
	ttk.Label(tab1, 
		text ="Standard Gateway V6\n(Dette er routeren din)", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 8, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')  # Eng: Default Gateway V6\n(This is your router)
	if not OnNetWork:
		DefGWv6 = "Ingen aktive nettverkskort" # Eng: No active network cards
  
	ttk.Label(tab1, 
		text = DefGWv6+"\n ", anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 8, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 
	ttk.Label(tab1, 
		text ="MAC-adresse\n ", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 9, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: MAC address

	if not OnNetWork:
		MacAddr = "Ingen aktive nettverkskort" # Eng: No active network cards
 
	ttk.Label(tab1, 
		text = MacAddr+"\n ", anchor="w").grid(column = 1, 
									row = 9, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') 




	# CPU
	ttk.Label(tab2, 
		text = "CPU\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
									row = 0, 
									padx = 10, 
									pady = 3,
                                    columnspan=2) # Eng: CPU
 
	ttk.Label(tab2, 
		text = "Prosessor", font=("Verdana", 8, "bold")).grid(column = 0, 
			    					row = 1, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Processor
	ttk.Label(tab2, 
		text = CPUProc, anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 1, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW',
                                    columnspan=2)
	ttk.Label(tab2, 
		text = "Fysiske kjerner", font=("Verdana", 8, "bold")).grid(column = 0, 
			    					row = 2, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Physical kernels
	ttk.Label(tab2, 
		text = psutil.cpu_count(logical=False), anchor="e", font=("Verdana", 8)).grid(column = 1, 
									row = 2, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	ttk.Label(tab2, 
		text = "stykk", anchor="w", font=("Verdana", 8)).grid(column = 2, 
									row = 2, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: pieces
  
	ttk.Label(tab2, 
		text = "Totalt antall kjerner", font=("Verdana", 8, "bold")).grid(column = 0, 
			    					row = 3, 
									padx = 10, 
									pady = 1,
                                    sticky='NESW') # Eng: Total number of kernels
	ttk.Label(tab2, 
		text = psutil.cpu_count(logical=True), anchor="e", font=("Verdana", 8)).grid(column = 1, 
									row = 3, 
									padx = 10, 
									pady = 1,
                                    sticky='NESW')
	ttk.Label(tab2, 
		text = "stykk", anchor="w", font=("Verdana", 8)).grid(column = 2, 
									row = 3, 
									padx = 10, 
									pady = 1,
                                    sticky='NESW') # Eng: pieces  
  
	ttk.Label(tab2, 
		text = "Maksimum CPU-frekvens", font=("Verdana", 8, "bold")).grid(column = 0, 
			    					row = 4, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Max CPU frequency
	ttk.Label(tab2, 
		text = f"{cpufreq.max:.2f}", anchor="e", font=("Verdana", 8)).grid(column = 1, 
									row = 4, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	ttk.Label(tab2, 
		text = "Mhz", anchor="w", font=("Verdana", 8)).grid(column = 2, 
									row = 4, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Mhz
  
  
	ttk.Label(tab2, 
		text = "Nåværende CPU-frekvens", font=("Verdana", 8, "bold")).grid(column = 0, 
			    					row = 5, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Currnt CPU frequency
	ttk.Label(tab2, 
		text = f"{cpufreq.current:.2f}", anchor="e", font=("Verdana", 8)).grid(column = 1, 
									row = 5, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	ttk.Label(tab2, 
		text = "Mhz", anchor="w", font=("Verdana", 8)).grid(column = 2, 
									row = 5, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Mhz
  
	ttk.Label(tab2, 
		text = "Nåværende CPU-bruk", font=("Verdana", 8, "bold")).grid(column = 0, 
			    					row = 6, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: Current CPU usage
	ttk.Label(tab2, 
		text = f"{psutil.cpu_percent()}", anchor='e', font=("Verdana", 8)).grid(column = 1, 
									row = 6, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW')
	ttk.Label(tab2, 
		text = "%", anchor="w", font=("Verdana", 8)).grid(column = 2, 
									row = 6, 
									padx = 10, 
									pady = 3,
                                    sticky='NESW') # Eng: %
  

	# Memory
	ttk.Label(tab3, text = "Minne\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
							       row = 0, 
							       padx = 10, 
							       pady = 1,
                                   columnspan=2) # Eng: Memory 

	ttk.Label(tab3, text = "Totalt minne:", font=("Verdana", 8, "bold")).grid(column = 0, 
							       row = 1, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW') # Eng: Total memory
 
	ttk.Label(tab3, text = memsize, anchor="e", font=("Verdana", 8)).grid(column = 1, 
							       row = 1, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')

	ttk.Label(tab3, text = "Brukt minne:", font=("Verdana", 8, "bold")).grid(column = 0, 
							       row = 2, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW') # Eng: Used memory
 
	ttk.Label(tab3, text = memused, anchor="e", font=("Verdana", 8)).grid(column = 1, 
							       row = 2, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')
 
	ttk.Label(tab3, text = "Ledig minne:", font=("Verdana", 8, "bold")).grid(column = 0, 
							       row = 3, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW') # Eng: Free memory
 
	ttk.Label(tab3, text = memfree, anchor="e", font=("Verdana", 8)).grid(column = 1, 
							       row = 3, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')

	ttk.Label(tab3, text = "", font=("Verdana", 8)).grid(column = 0, 
							       row = 4, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW')

	ttk.Label(tab3, text = "", font=("Verdana", 8), anchor="e").grid(column = 1, 
							       row = 5, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')

	ttk.Label(tab3, text = "Swap\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
							       row = 5, 
							       padx = 10, 
							       pady = 1,
                                   columnspan=2) # Eng: Swap

	ttk.Label(tab3, text = "Total swap", font=("Verdana", 8, "bold")).grid(column = 0, 
							       row = 6, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW') # Eng: Total swap
 
	ttk.Label(tab3, text = swaptotal, anchor="e", font=("Verdana", 8)).grid(column = 1, 
							       row = 6, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')
 
	ttk.Label(tab3, text = "Brukt swap", font=("Verdana", 8, "bold")).grid(column = 0, 
							       row = 7, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW') # Used swap
 
	ttk.Label(tab3, text = swapused, anchor="e", font=("Verdana", 8)).grid(column = 1, 
							       row = 7, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')
 
	ttk.Label(tab3, text = "Ledig swap", font=("Verdana", 8, "bold")).grid(column = 0, 
							       row = 8, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW') # Eng: Free swap
 
	ttk.Label(tab3, text = swapfree, anchor="e", font=("Verdana", 8)).grid(column = 1, 
							       row = 8, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')
 
	ttk.Label(tab3, text = "").grid(column = 0, 
							       row = 9, 
							       padx = 10, 
							       pady = 1,
                                   sticky='NESW')

	ttk.Label(tab3, text = "").grid(column = 1, 
							       row = 9, 
							       padx = 10, 
							       pady = 1, 
                                   sticky='NESW')

  
	# Disks
	ttk.Label(tab4, 
		text = "Disk(er)\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
									row = 0, 
									padx = 10, 
									pady = 3,
                					columnspan=5) # Eng: Disk(s)

	ttk.Label(tab4, 
		text = "Disk", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 1, 
									padx = 10, 
									pady = 3) # Eng Disk
	ttk.Label(tab4, 
		text = "Total diskplass", font=("Verdana", 8, "bold")).grid(column = 1, 
									row = 1, 
									padx = 10, 
									pady = 3) # Totel disk space
	ttk.Label(tab4, 
		text = "Brukt diskplass", font=("Verdana", 8, "bold")).grid(column = 2, 
									row = 1, 
									padx = 10, 
									pady = 3) # Eng: Used disk space
	ttk.Label(tab4, 
		text = "Ledig diskplass", font=("Verdana", 8, "bold")).grid(column = 3, 
									row = 1, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: Free disk space
	ttk.Label(tab4, 
		text = "Ledig diskplass i prosent", font=("Verdana", 8, "bold")).grid(column = 4, 
									row = 1, 
									padx = 10, 
									pady = 3)
	# The first counter «i» goes through dhe disks and give a number for the row
	for i, disk in enumerate(disk_partitions()):
    	# Fetching the info here and not at the top because I need it to be inside
    	# a for-loop.
		str = disk.device
		DiskLetter = (str).replace("\\", "/")
		CleanDiskLetter = (str).replace("\\", "").replace(":", "") # No need for last replace on this line for Eng version
    	# For each drive, we have to make the human readable values.
    	# Since this app is Norwegian, I change the decimal devider to comma. 
		hdd = psutil.disk_usage(DiskLetter)
		HddTotal = (bytes2human(hdd.total).replace(',', ' '))
		HddFree = bytes2human(hdd.free).replace(',', ' ').replace(".",",")
		HddUsed = (bytes2human(hdd.used).replace(',', ' '))
		HddPercent = (bytes2human(100-hdd.percent).replace(',', ' ').replace(".",",")+"%")
		
		ttk.Label(tab4, 
				text =CleanDiskLetter+":").grid(column = 0, 
									row = i+2, 
									padx = 10, 
									pady = 3,
         							sticky='NESW') 
		ttk.Label(tab4, 
				text = HddTotal, anchor="e").grid(column = 1, 
									row = i+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 
		ttk.Label(tab4, 
				text = HddUsed, anchor="e").grid(column = 2, 
									row = i+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 
		ttk.Label(tab4, 
				text = HddFree, anchor="e").grid(column = 3, 
									row = i+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 
		ttk.Label(tab4, 
				text = HddPercent, anchor="e").grid(column = 4, 
									row = i+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW')
		
	
	wmi_obj_1 = wmi.WMI(namespace='root/Microsoft/Windows/Storage')
	# As «i» was used «j» is the offset from «i» to give some space for next listing
	j = i+3
	# And after «j», comes «k» that is used to place the health status of the disks
	# below the dqata about the disk
	k = j+1
	# Description line after one empty line
	ttk.Label(tab4, 
				text = "", anchor="w").grid(column = 0, 
									row = i+4, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW', 
                					columnspan=5)
	ttk.Label(tab4, 
				text = "Disk ID", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = i+5, 
									padx = 10, 
									pady = 3) # Eng: Disk ID
	ttk.Label(tab4, 
				text = "Modell", font=("Verdana", 8, "bold"), anchor="w").grid(column = 1, 
									row = i+5, 
									padx = 10, 
									pady = 3) # Eng: Model
	ttk.Label(tab4, 
				text = "Bus type", font=("Verdana", 8, "bold"), anchor="w").grid(column = 2, 
									row = i+5, 
									padx = 10, 
									pady = 3) # Eng: Bus type
	ttk.Label(tab4, 
				text = "Media type", font=("Verdana", 8, "bold"), anchor="w").grid(column = 3, 
									row = i+5, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: Media type
	ttk.Label(tab4, 
				text = "Firmware versjon", font=("Verdana", 8, "bold"), anchor="w").grid(column = 4, 
									row = i+5, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: Firmware version
    
	for d in wmi_obj_1.MSFT_PhysicalDisk():
    	# print(d.DeviceID, d.BusType, d.MediaType, d.Model)
		MediaTypeName = ["Uspesifisert", "", "", "HDD", "SSD", "SCM"] # Eng: "Uspcsified", "", "", "HDD", "SSD", "SCM"
		BusTypeName =["Busstypen er ukjent.", "SCSI", "ATAPI", "ATA", "IEEE 1394", "SSA", "Fiberkanal", "USB", "RAID", "iSCSI", "Seriell tilkoblet SCSI (SAS)", "Seriell ATA (SATA)", "Secure Digital (SD)", "Multimedia kort (MMC)", "MAX - Denne verdien er reservert for systembruk.", "Filstøttet virtuell", "Oppbevaringsplasser", "Ikke-flyktig Memory Express (NVME)", "SCM", "UFS", "Microsoft reservert"] # Eng: "Unknown bus type.", "SCSI", "ATAPI", "ATA", "IEEE 1394", "SSA", "Fibre channel", "USB", "RAID", "iSCSI", "Serial attached SCSI (SAS)", "Serial ATA (SATA)", "Secure Digital (SD)", "Multimedia card (MMC)", "MAX - This value is reserved for system use.", "File-backed virtual", "Storage spaces", "Non Voletile Memory Express (NVME)", "SCM", "UFS", "Microsoft reserved"
		HealthStatusMeaning = ["Disken er i orden.", "Advarsel, skjekk disken!", "Disken er usunn og har problemer!", "", "", "Helse ukjent"] # Eng: "The disk is healty.", "Warning chack the disk!", "Unhealty", "", "", "Unknown"
		j = j + 1
		ttk.Label(tab4, 
				text = "Disk: " + d.DeviceID , anchor="w", font=("Verdana", 8)).grid(column = 0, 
									row = i+j+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: Disk
		ttk.Label(tab4, 
				text = d.Model, font=("Verdana", 8), anchor="w").grid(column = 1, 
									row = i+j+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW')
		ttk.Label(tab4, 
				text = BusTypeName[d.BusType], font=("Verdana", 8), anchor="w").grid(column = 2, 
									row = i+j+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW')
		ttk.Label(tab4, 
				text = MediaTypeName[d.MediaType], font=("Verdana", 8), anchor="w").grid(column = 3, 
									row = i+j+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 
		ttk.Label(tab4, 
				text = d.FirmwareVersion, anchor="w", font=("Verdana", 8)).grid(column = 4, 
									row = i+j+2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW')
		ttk.Label(tab4, 
				text = "Disk " + d.DeviceID + " sin helsestatus: ", font=("Verdana", 8, "bold"), anchor="w").grid(column = 0, 
									row = i+j+k, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: "Health status of Disk " + d.DeviceID 
		ttk.Label(tab4, 
				text = HealthStatusMeaning[d.HealthStatus], anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = i+j+k, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW',
                					columnspan=3)
  
  
	# Operating system
	ttk.Label(tab5, 
			text ="Operativsystem\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
									row = 0, 
									padx = 10, 
									pady = 3,
                					columnspan=2) # Eng: Operating system
	ttk.Label(tab5, 
			text ="Operativsystem:", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 1, 
									padx = 10, 	
									pady = 3,	
         							sticky='NESW') # Eng: Operating system
	ttk.Label(tab5, 
			text = OSName, anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 1, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 
	ttk.Label(tab5, 
			text ="Versjon:", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 2, 
									padx = 10, 	
									pady = 3,	
         							sticky='NESW') # Eng: Version
	ttk.Label(tab5, 
			text = OSVersion, anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 
	ttk.Label(tab5, 
			text ="For maskintype:", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 3, 
									padx = 10, 	
									pady = 3,	
         							sticky='NESW') # For machine type
	ttk.Label(tab5, 
			text = OSMachine, anchor="w", font=("Verdana", 8)).grid(column = 1, 
									row = 3, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 


	# About 
	ttk.Label(tab6, 
		text ="MiniInfo\n", foreground="blue", font=("Verdana", 16, "bold")).grid(column = 0, 
									row = 0, 
									padx = 10, 
									pady = 3,	
         						#	sticky='NESW',
                					columnspan=2)
	ttk.Label(tab6, 
		text ="Copyleft Nalle Berg 2025", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 1, 
									padx = 10, 
									pady = 3,	
         							#sticky='NESW',
                					columnspan=2) # Eng: Copyleft Nalle Berg 2025
	ttk.Label(tab6, 
		text ="Lisens", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Licence
	ttk.Label(tab6, 
		text ="GPL V2", anchor="w").grid(column = 1, 
									row = 2, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: GPL V2
	ttk.Label(tab6, 
		text ="Versjon", anchor="w", font=("Verdana", 8, "bold")).grid(column = 0, 
									row = 3, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') # Eng: version
	ttk.Label(tab6, 
		text ="Om du ønsker kildekode, så finner du den på https://prog.nalle.no").grid(column = 0, 
									row = 4, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW',
                					columnspan=2) # Eng: if you want source code, you will find it at https://prog.nalle.no
	ttk.Label(tab6, 
		text = AppVersion, anchor="w").grid(column = 1, 
									row = 3, 
									padx = 10, 
									pady = 3,	
         							sticky='NESW') 

	Window.mainloop() 

if __name__ == "__main__":
    main()
